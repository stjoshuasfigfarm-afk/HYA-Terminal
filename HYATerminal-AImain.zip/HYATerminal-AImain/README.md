# HY Analysts Terminal

A production-ready financial intelligence terminal built with Vanilla JS, Tailwind CSS, and Leaflet.js.

## Features
- **Global Asset Map**: Visualizing major corporate nodes with supply chain logic (Upstream/Downstream).
- **Deep Packet Inspection**: Real-time financial profiles, balance sheet snapshots, and income history.
- **Dynamic Charting**: High-performance price visualization via Lightweight Charts.
- **News Ticker**: Rolling news intelligence feed.

## Prerequisites
- Node.js (v18+)
- Financial Data API Key (Recommended: [Financial Modeling Prep](https://site.financialmodelingprep.com/))

## Environment Variables

The application requires several API keys for full functionality. A priority chain is used to ensure resilience if one provider is offline.

### Required Keys:
- `FINANCIAL_API_KEY`: Primary catch-all key (Supports FMP and FinancialData.net mocks).
- `FINNHUB_API_KEY`: Priority for Company Profiles and Quotes.
- `FMP_API_KEY`: Used for Financial Statements and Quotes.
- `ITICK_API_KEY`: Part of the Quote priority chain.
- `ALPACA_API_KEY` & `ALPACA_SECRET_KEY`: Fallback for latest stock quotes.
- `MARKETAUX_API_KEY`: Required for the Live News Ticker stream.

### Setting Up Locally:
1. Copy `.env.example` to a new file named `.env`.
2. Fill in your API keys in the `.env` file.
3. The server will automatically load these variables on start.

### Setting Up on Vercel:
1. Go to your **Project Dashboard**.
2. Navigate to **Settings** > **Environment Variables**.
3. Add the keys listed above (e.g., `FINNHUB_API_KEY`).
4. Trigger a new deployment for changes to take effect.

## Local Development
1. Clone the repository.
2. Run `npm install`.
3. Create a `.env` file based on `.env.example`.
4. Run `npm run dev`.
5. Open `http://localhost:3000`.

## Deployment to Vercel
1. Set up a new project on [Vercel](https://vercel.com).
2. Connect your GitHub repository.
3. Deploy.

## Backend Architecture

The app uses a dual-mode backend:
- **Local Development**: `server.ts` (Express) handles API routing and priority chains.
- **Production (Vercel)**: Serverless functions in the `api/` directory handle requests.

The **Priority Chain** for quotes follows this logic:
1. `FinancialData.net`
2. `iTick`
3. `Finnhub`
4. `Financial Modeling Prep (FMP)`
5. `Alpaca`
6. `Simulation Fallback` (If all keys are missing/requests fail).

## Technology Stack
- **Frontend**: Vanilla JS, Leaflet, Lightweight Charts, Tailwind CSS.
- **Backend**: Node.js (CommonJS for Vercel Serverless Functions).
- **Styling**: JetBrains Mono (Typography), Dark-Brutalist (Theme).
