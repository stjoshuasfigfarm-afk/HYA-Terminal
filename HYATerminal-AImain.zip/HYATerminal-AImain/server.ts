import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import axios from "axios";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Proxy Handlers with Priority Chains
  app.get("/api/quote", async (req, res) => {
    const { symbol } = req.query;
    if (!symbol) return res.status(400).json({ error: "Symbol required" });

    const s = symbol.toString().toUpperCase();
    
    // Priority Chain: FinancialData.net -> iTick -> Finnhub -> FMP -> Alpaca
    const providers = [
      async () => {
        if (!process.env.FINANCIAL_API_KEY) throw new Error("No Key");
        const r = await axios.get(`https://api.financialdata.net/v1/quote?symbol=${s}&apikey=${process.env.FINANCIAL_API_KEY}`, { timeout: 2000 });
        return { price: r.data.price, change: r.data.change, changePercent: r.data.change_percent, source: "FinancialData.net" };
      },
      async () => {
        if (!process.env.ITICK_API_KEY) throw new Error("No Key");
        const r = await axios.get(`https://api.itick.org/v1/quote?symbol=${s}&apikey=${process.env.ITICK_API_KEY}`, { timeout: 2000 });
        return { price: r.data.price, change: r.data.change, changePercent: r.data.changePercent, source: "iTick" };
      },
      async () => {
        if (!process.env.FINNHUB_API_KEY) throw new Error("No Key");
        const r = await axios.get(`https://finnhub.io/api/v1/quote?symbol=${s}&token=${process.env.FINNHUB_API_KEY}`, { timeout: 2000 });
        return { price: r.data.c, change: r.data.d, changePercent: r.data.dp, source: "Finnhub" };
      },
      async () => {
        const key = process.env.FMP_API_KEY || process.env.FINANCIAL_API_KEY; // Fallback to provided key
        if (!key) throw new Error("No Key");
        const r = await axios.get(`https://financialmodelingprep.com/api/v3/quote/${s}?apikey=${key}`, { timeout: 2000 });
        if (r.data?.[0]) {
          const q = r.data[0];
          return { price: q.price, change: q.change, changePercent: q.changesPercentage, source: "FMP" };
        }
        throw new Error("No Data");
      },
      async () => {
        if (!process.env.ALPACA_API_KEY || !process.env.ALPACA_SECRET_KEY) throw new Error("No Key");
        const r = await axios.get(`https://data.alpaca.markets/v2/stocks/${s}/quotes/latest`, {
          headers: { 'APCA-API-KEY-ID': process.env.ALPACA_API_KEY, 'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY },
          timeout: 2000
        });
        return { price: r.data.quote.ap, change: 0, changePercent: 0, source: "Alpaca" }; // Alpaca latest quote often just price
      }
    ];

    for (const fetcher of providers) {
      try {
        const data = await fetcher();
        if (data && data.price) return res.json(data);
      } catch (e) {}
    }

    // Default Fallback
    res.json({ symbol: s, price: (150 + Math.random() * 50).toFixed(2), change: "0.00", changePercent: "0.00", source: "Simulation" });
  });

  app.get("/api/company", async (req, res) => {
    const { symbol } = req.query;
    if (!symbol) return res.status(400).json({ error: "Symbol required" });
    const s = symbol.toString().toUpperCase();

    // Priority Chain: Finnhub -> FinancialData.net -> FMP
    const providers = [
      async () => {
        if (!process.env.FINNHUB_API_KEY) throw new Error("No Key");
        const r = await axios.get(`https://finnhub.io/api/v1/stock/profile2?symbol=${s}&token=${process.env.FINNHUB_API_KEY}`, { timeout: 2000 });
        return { name: r.data.name, sector: r.data.finnhubIndustry, employees: r.data.fullTimeEmployees || "N/A", marketCap: (r.data.marketCapitalization/1000).toFixed(2)+"T", source: "Finnhub" };
      },
      async () => {
        if (!process.env.FINANCIAL_API_KEY) throw new Error("No Key");
        const r = await axios.get(`https://api.financialdata.net/v1/company?symbol=${s}&apikey=${process.env.FINANCIAL_API_KEY}`, { timeout: 2000 });
        return { name: r.data.name, sector: r.data.sector, employees: r.data.employees, marketCap: r.data.market_cap, source: "FinancialData.net" };
      },
      async () => {
        const key = process.env.FMP_API_KEY || process.env.FINANCIAL_API_KEY;
        if (!key) throw new Error("No Key");
        const r = await axios.get(`https://financialmodelingprep.com/api/v3/profile/${s}?apikey=${key}`, { timeout: 2000 });
        if (r.data?.[0]) {
          const p = r.data[0];
          return { name: p.companyName, sector: p.sector, employees: p.fullTimeEmployees, marketCap: (p.mktCap/1e12).toFixed(2)+"T", source: "FMP" };
        }
        throw new Error("No Data");
      }
    ];

    for (const fetcher of providers) {
      try {
        const data = await fetcher();
        if (data && data.name) return res.json(data);
      } catch (e) {}
    }

    res.json({ name: s + " Corp", sector: "Financial Services", employees: "10,000", marketCap: "1.2T", source: "Simulation" });
  });

  app.get("/api/income", async (req, res) => {
    const { symbol } = req.query;
    if (!symbol) return res.status(400).json({ error: "Symbol required" });
    const s = symbol.toString().toUpperCase();

    // Priority Chain: FinancialData.net (quarterly) -> FMP (annual)
    const providers = [
      async () => {
        if (!process.env.FINANCIAL_API_KEY) throw new Error("No Key");
        const r = await axios.get(`https://api.financialdata.net/v1/income?symbol=${s}&period=quarter&apikey=${process.env.FINANCIAL_API_KEY}`, { timeout: 2000 });
        return { quarters: r.data.map((i: any) => ({ date: i.date, revenue: i.revenue, netIncome: i.net_income })), source: "FinancialData.net" };
      },
      async () => {
        const key = process.env.FMP_API_KEY || process.env.FINANCIAL_API_KEY;
        if (!key) throw new Error("No Key");
        const r = await axios.get(`https://financialmodelingprep.com/api/v3/income-statement/${s}?limit=4&apikey=${key}`, { timeout: 2000 });
        if (r.data && Array.isArray(r.data)) {
          return { quarters: r.data.map((i: any) => ({ date: i.date, revenue: i.revenue, netIncome: i.netIncome })), source: "FMP" };
        }
        throw new Error("No Data");
      }
    ];

    for (const fetcher of providers) {
      try {
        const data = await fetcher();
        if (data && data.quarters) return res.json(data);
      } catch (e) {}
    }

    res.json({ quarters: [{ date: "2023-12-31", revenue: 50e9, netIncome: 20e9 }, { date: "2023-09-30", revenue: 48e9, netIncome: 18e9 }], source: "Simulation" });
  });

  app.get("/api/balance", async (req, res) => {
    const { symbol } = req.query;
    if (!symbol) return res.status(400).json({ error: "Symbol required" });
    const s = symbol.toString().toUpperCase();

    // Priority Chain: FinancialData.net -> FMP
    const providers = [
      async () => {
        if (!process.env.FINANCIAL_API_KEY) throw new Error("No Key");
        const r = await axios.get(`https://api.financialdata.net/v1/balance?symbol=${s}&apikey=${process.env.FINANCIAL_API_KEY}`, { timeout: 2000 });
        return { totalAssets: r.data.total_assets, totalDebt: r.data.total_debt, cashAndCashEquivalents: r.data.cash, totalEquity: r.data.equity, source: "FinancialData.net" };
      },
      async () => {
        const key = process.env.FMP_API_KEY || process.env.FINANCIAL_API_KEY;
        if (!key) throw new Error("No Key");
        const r = await axios.get(`https://financialmodelingprep.com/api/v3/balance-sheet-statement/${s}?limit=1&apikey=${key}`, { timeout: 2000 });
        if (r.data?.[0]) {
          const b = r.data[0];
          return { totalAssets: b.totalAssets, totalDebt: b.totalTotalDebt, cashAndCashEquivalents: b.cashAndCashEquivalents, totalEquity: b.totalStockholdersEquity, source: "FMP" };
        }
        throw new Error("No Data");
      }
    ];

    for (const fetcher of providers) {
      try {
        const data = await fetcher();
        if (data && data.totalAssets) return res.json(data);
      } catch (e) {}
    }

    res.json({ totalAssets: 300e9, totalDebt: 100e9, cashAndCashEquivalents: 50e9, totalEquity: 200e9, source: "Simulation" });
  });

  app.get("/api/news", async (req, res) => {
    const { symbol } = req.query;
    const apiKey = process.env.MARKETAUX_API_KEY;
    if (!apiKey) return res.json({ articles: [{ title: "MARKET NEWS UNAVAILABLE - NO API KEY", source: "System" }] });
    
    try {
      const url = `https://api.marketaux.com/v1/news/all?symbols=${symbol || 'AAPL,MSFT,TSLA'}&filter_entities=true&limit=10&api_token=${apiKey}`;
      const response = await axios.get(url, { timeout: 3000 });
      res.json({ articles: response.data.data || [] });
    } catch (e) {
      res.json({ articles: [{ title: "ERROR FETCHING NEWS STREAM", source: "System" }] });
    }
  });

  // Serve the index.html from root
  app.get("/", (req, res) => {
    res.sendFile(path.join(process.cwd(), "index.html"));
  });

  // Static Assets
  app.use(express.static(process.cwd()));

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[TERMINAL] HY Analysts Terminal Online: http://localhost:${PORT}`);
  });
}

startServer();
